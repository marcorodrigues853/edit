let titulo= 'Isto é um título longo de um livro';

console.log(titulo);
console.log(titulo.replace('livro', 'diário'));



titulo =titulo + ' mas não faz mal porque não é uma seca';

console.log(titulo)

console.log(titulo.slice(0, 11))
